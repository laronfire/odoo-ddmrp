To plan buffer adjustments act as follows:

#. Click on *Inventory > Demand Planning > Create Buffer Adjustments*.
#. In the popup window fill the *Period* and *Date Range Type* to perform
   your planning.
#. Check the boxes of the *Factor to Apply* in which you are interested.
#. Select the DDMRP Buffers where to apply this factors.
#. Under the title *Sheet* you will see a generated sheet in which you can
   fill the values for each period.
#. Click *Validate* to confirm your planning and the system will end up
   showing you the newly created DDMRP adjustment records.
