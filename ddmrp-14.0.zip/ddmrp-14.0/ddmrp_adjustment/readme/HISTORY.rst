13.0.1.0.0 (2020-07-02)
~~~~~~~~~~~~~~~~~~~~~~~

* Standard migration to v13.

11.0.1.1.0 (2019-02-01)
~~~~~~~~~~~~~~~~~~~~~~~

* Refactor data model to reduce complexity. Functionality unchanged.

11.0.1.0.0 (2018-08-01)
~~~~~~~~~~~~~~~~~~~~~~~

* Start of the history
