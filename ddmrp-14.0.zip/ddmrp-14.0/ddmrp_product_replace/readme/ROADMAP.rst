* Option to create new buffer and make old ones inactive.
* Consider Demand estimates in the replacement.
