Provides a tool for product replacement.
