Go to *Inventory > Configuration > DDMRP > Product Replacement Tool*.

Then you can fill the wizard options to complete the replacement. There are two
modes of operation: *Create a new buffer for the replacing product* and
*Replace product in existing buffers*.
