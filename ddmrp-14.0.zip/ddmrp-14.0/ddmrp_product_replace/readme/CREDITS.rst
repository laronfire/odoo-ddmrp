The initial development of this module has been financially supported by:

* Aleph Objects, Inc.

The migration of this module from 13.0 to 14.0 was financially supported by Camptocamp
