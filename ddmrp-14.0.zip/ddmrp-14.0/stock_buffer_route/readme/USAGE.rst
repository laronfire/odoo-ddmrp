Go to the stock buffer and change the route. Only the routes applicable
for this location or locations above it can be selected.
