This module allows to restrict a specific route to be used in the
ddmrp stock buffers. This route will be used instead of the default determined by
default.
