Show the number of stock coverage days in the stock buffer.
