This DDMRP module removes on the purchase order form the On-Hand status
information in the list of purchase line. This can help on loading time for
large purchase order.
A smart button is added on the form `Line On-Hand status` to visualize the
removed information.
