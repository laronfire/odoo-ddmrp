Adds chatter and activities to stock buffers.
