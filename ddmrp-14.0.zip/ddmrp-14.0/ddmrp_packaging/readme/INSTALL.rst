It is recommended to use this module in conjunction with
`purchase_order_line_packaging_qty <https://github.com/OCA/purchase-workflow/tree/13.0/purchase_order_line_packaging_qty>`_.
