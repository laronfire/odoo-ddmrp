This module integrate packagings into the DDMRP app.
