13.0.1.0.0 (2021-03-15)
~~~~~~~~~~~~~~~~~~~~~~~

* Standard migration of the module to v13.

11.0.1.0.0 (2018-09-17)
~~~~~~~~~~~~~~~~~~~~~~~

* Start of history. Migrated to OCA/ddmrp.
