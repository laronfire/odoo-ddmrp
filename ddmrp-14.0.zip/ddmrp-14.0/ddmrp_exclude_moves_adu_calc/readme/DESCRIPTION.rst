This module adds new criteria to exclude moves from the calculation of the
Average Daily Usage (ADU) on a Buffer, based on:

* Locations
* Specific stock moves
