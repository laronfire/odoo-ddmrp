Allows to access the sales analysis from a stock buffer,
through a smart button visible for the members of the group
*User: Own Documents Only* (same as the original permissions
for the same smart button shown in products).
