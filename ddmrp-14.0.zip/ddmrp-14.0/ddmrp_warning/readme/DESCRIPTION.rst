Adds configuration warnings on stock buffers based on different definitions.
This modules include some basic warnings but you can create your own based on
your environment.
