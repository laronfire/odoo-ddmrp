To use this module you can proceed as follows:

#. Use the filter *Has Warnings* in stock buffers.
#. In a buffer form view go to the *Warnings* tab and check the active warnings.
#. Fix the issues, and click on *Refresh Warnings*.
