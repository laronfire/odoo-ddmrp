Add the *Storage Capacity Limit* field to stock buffers, which restricts
recommended procurement quantity to ensure that the limits of storage are
never surpassed.
